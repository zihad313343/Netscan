package com.eduscan.netscan.network

/**
 * Small, hand-picked table of common MAC OUI prefixes -> vendor name.
 * NOTE: This is a tiny sample, not the full IEEE registry (which has 40,000+ entries).
 * It's here to give a "good enough" vendor hint for common household devices.
 * For exhaustive/accurate lookups you'd query the IEEE OUI database or an online API.
 */
object OuiVendorDb {

    private val prefixToVendor: Map<String, String> = mapOf(
        "00:1A:11" to "Google", "F4:F5:D8" to "Google", "3C:5A:B4" to "Google",
        "A4:77:33" to "Google", "94:EB:2C" to "Google",
        "AC:DE:48" to "Apple", "A8:66:7F" to "Apple", "F0:18:98" to "Apple",
        "BC:52:B7" to "Apple", "3C:22:FB" to "Apple", "D0:03:4B" to "Apple",
        "F8:1E:DF" to "Apple", "88:63:DF" to "Apple", "AC:BC:32" to "Apple",
        "5C:F9:38" to "Apple", "70:56:81" to "Apple",
        "E4:E0:C5" to "Samsung", "8C:79:F5" to "Samsung", "5C:0A:5B" to "Samsung",
        "34:23:87" to "Samsung", "CC:07:AB" to "Samsung", "D0:59:E4" to "Samsung",
        "78:D6:F0" to "Xiaomi", "F0:B4:29" to "Xiaomi", "64:CC:2E" to "Xiaomi",
        "AC:37:43" to "Huawei", "F8:3D:FF" to "Huawei", "00:E0:FC" to "Huawei",
        "B8:27:EB" to "Raspberry Pi Foundation", "DC:A6:32" to "Raspberry Pi Foundation",
        "E4:5F:01" to "Raspberry Pi Foundation",
        "00:1B:63" to "Apple (legacy)", "00:50:56" to "VMware",
        "08:00:27" to "VirtualBox", "00:0C:29" to "VMware",
        "B0:BE:76" to "Sonos", "5C:AA:FD" to "Sonos",
        "EC:FA:BC" to "TP-Link", "50:C7:BF" to "TP-Link", "A4:2B:B0" to "TP-Link",
        "44:D9:E7" to "Amazon", "68:37:E9" to "Amazon", "F0:81:73" to "Amazon",
        "18:B4:30" to "Nest Labs", "64:16:66" to "Nest Labs",
        "3C:71:BF" to "Netgear", "A0:40:A0" to "Netgear",
        "00:11:32" to "Synology", "00:1C:14" to "Synology"
    )

    /** Returns a vendor guess given a full MAC like "AC:DE:48:12:34:56", or null if unknown. */
    fun lookup(mac: String?): String? {
        if (mac.isNullOrBlank()) return null
        val normalized = mac.uppercase().replace("-", ":")
        val prefix = normalized.split(":").take(3).joinToString(":")
        return prefixToVendor[prefix]
    }
}
