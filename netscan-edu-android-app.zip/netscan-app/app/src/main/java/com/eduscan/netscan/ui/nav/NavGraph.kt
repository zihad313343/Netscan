package com.eduscan.netscan.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.eduscan.netscan.ui.screens.AboutScreen
import com.eduscan.netscan.ui.screens.HomeScreen
import com.eduscan.netscan.ui.screens.LocalNetworkScreen
import com.eduscan.netscan.ui.screens.PortScanScreen
import com.eduscan.netscan.ui.screens.SubdomainScreen

private object Routes {
    const val HOME = "home"
    const val PORT_SCAN = "port_scan"
    const val LOCAL_NETWORK = "local_network"
    const val SUBDOMAIN_FINDER = "subdomain_finder"
    const val ABOUT = "about"
}

@Composable
fun NetScanNavGraph() {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenPortScanner = { navController.navigate(Routes.PORT_SCAN) },
                onOpenLocalNetwork = { navController.navigate(Routes.LOCAL_NETWORK) },
                onOpenSubdomainFinder = { navController.navigate(Routes.SUBDOMAIN_FINDER) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.PORT_SCAN) {
            PortScanScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.LOCAL_NETWORK) {
            LocalNetworkScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SUBDOMAIN_FINDER) {
            SubdomainScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
