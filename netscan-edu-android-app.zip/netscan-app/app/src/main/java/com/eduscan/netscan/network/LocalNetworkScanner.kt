package com.eduscan.netscan.network

import android.content.Context
import android.net.wifi.WifiManager
import com.eduscan.netscan.model.NetworkDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Discovers live hosts on the device's current /24 WiFi subnet.
 *
 * IMPORTANT LIMITATIONS (by design of modern Android, not a bug here):
 *  - Android 10+ heavily restricts raw ARP-table access and MAC randomization means
 *    many devices won't reveal a stable, real MAC address at all. ARP lookups here
 *    are best-effort and may come back empty on a lot of devices/ROMs.
 *  - There is no public Android API to ask "what model of phone is at 192.168.1.5?".
 *    We can only report what a device chooses to advertise: its DHCP/mDNS hostname
 *    (which often, but not always, hints at the model, e.g. "Johns-iPhone") and a
 *    vendor guess from the MAC OUI when we can read it.
 */
object LocalNetworkScanner {

    private const val CONNECT_TIMEOUT_MS = 400
    private const val MAX_CONCURRENCY = 64
    // Ports to try as a TCP-reachability fallback when ICMP (isReachable) is blocked.
    private val PROBE_PORTS = intArrayOf(80, 443, 445, 139, 22, 62078, 8080, 5000, 5353)

    data class SubnetInfo(val localIp: String, val cidr: String, val hosts: List<String>)

    fun getSubnetInfo(context: Context): SubnetInfo? {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null

        @Suppress("DEPRECATION")
        val dhcpInfo = wifiManager.dhcpInfo ?: return null
        val ipInt = dhcpInfo.ipAddress
        if (ipInt == 0) return null

        val localIp = intToIp(ipInt)
        val prefix = localIp.substringBeforeLast(".")
        val hosts = (1..254).map { "$prefix.$it" }.filter { it != localIp }

        return SubnetInfo(localIp, "$prefix.0/24", hosts)
    }

    suspend fun scanSubnet(
        hosts: List<String>,
        localIp: String,
        onHostChecked: () -> Unit,
        onDeviceFound: (NetworkDevice) -> Unit
    ) = coroutineScope {
        val arpTable = readArpTable()
        val semaphore = Semaphore(MAX_CONCURRENCY)

        hosts.map { ip ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val device = probeHost(ip, arpTable)
                    onHostChecked()
                    if (device != null) onDeviceFound(device)
                }
            }
        }.awaitAll()
    }

    private fun probeHost(ip: String, arpTable: Map<String, String>): NetworkDevice? {
        val start = System.currentTimeMillis()
        val reachable = isHostReachable(ip)
        if (!reachable) return null
        val elapsed = System.currentTimeMillis() - start

        val hostname = resolveHostnameWithTimeout(ip)

        val mac = arpTable[ip]
        val vendor = OuiVendorDb.lookup(mac)
        val typeGuess = guessDeviceType(hostname, vendor)

        return NetworkDevice(
            ip = ip,
            hostname = hostname,
            macAddress = mac,
            vendorGuess = vendor,
            deviceTypeGuess = typeGuess,
            responseTimeMs = elapsed
        )
    }

    private fun isHostReachable(ip: String): Boolean {
        // NOTE: We deliberately do NOT use InetAddress.isReachable() here. On Android it has a
        // long-standing bug where it can ignore its timeout parameter entirely and block for
        // tens of seconds per host, which - across a subnet scan with limited concurrency - can
        // stall the whole scan. Socket.connect() with an explicit timeout is far more reliable,
        // so we use TCP probing on a handful of common ports as our only reachability check.
        // Total worst case per unreachable host is bounded: PROBE_PORTS.size * 250ms.
        for (port in PROBE_PORTS) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(ip, port), 250)
                    return true
                }
            } catch (e: Exception) {
                // try next port
            }
        }
        return false
    }

    /**
     * Reverse-DNS lookup has no built-in timeout in the Java API and can hang on a slow or
     * unresponsive router. We bound it with a short-lived daemon thread + join timeout so a
     * single slow lookup can never stall the overall scan.
     */
    private fun resolveHostnameWithTimeout(ip: String, timeoutMs: Long = 500): String? {
        var result: String? = null
        val thread = Thread {
            try {
                val hostname = InetAddress.getByName(ip).canonicalHostName
                if (hostname != ip) result = hostname
            } catch (e: Exception) {
                // leave result null
            }
        }
        thread.isDaemon = true
        thread.start()
        thread.join(timeoutMs)
        return result
    }

    /** Best-effort read of the kernel ARP table. May return empty on modern Android (expected). */
    private fun readArpTable(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        try {
            val file = File("/proc/net/arp")
            if (!file.exists() || !file.canRead()) return result
            BufferedReader(FileReader(file)).use { reader ->
                reader.readLine() // header
                var line = reader.readLine()
                while (line != null) {
                    val parts = line.trim().split(Regex("\\s+"))
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val mac = parts[3]
                        if (mac != "00:00:00:00:00:00") {
                            result[ip] = mac
                        }
                    }
                    line = reader.readLine()
                }
            }
        } catch (e: Exception) {
            // Expected to fail/be empty on many modern devices - not an error state.
        }
        return result
    }

    private fun guessDeviceType(hostname: String?, vendor: String?): String? {
        val h = hostname?.lowercase() ?: ""
        return when {
            "iphone" in h -> "Apple iPhone"
            "ipad" in h -> "Apple iPad"
            "macbook" in h -> "Apple Mac"
            "android" in h -> "Android device"
            "galaxy" in h -> "Samsung Galaxy"
            "pixel" in h -> "Google Pixel"
            "desktop-" in h -> "Windows PC"
            "raspberrypi" in h || "raspberry" in h -> "Raspberry Pi"
            vendor != null -> "$vendor device"
            else -> null
        }
    }

    private fun intToIp(ip: Int): String {
        return "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }
}
