package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eduscan.netscan.ui.components.SectionCard
import com.eduscan.netscan.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        containerColor = BgDeep,
        topBar = {
            TopAppBar(
                title = { Text("About & Disclaimer") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgSurfaceElevated, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionCard {
                Text("Purpose", color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "NetScan Edu is a learning tool for understanding how basic network reconnaissance works: " +
                        "TCP connect scanning, service identification from well-known ports, and banner grabbing. " +
                        "It's meant for students, hobbyists, and IT admins learning the fundamentals behind tools like Nmap.",
                    color = TextSecondary, style = MaterialTheme.typography.bodyMedium
                )
            }

            SectionCard {
                Text("Only scan what you're authorized to scan", color = StatusError, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Port scanning or probing devices, servers, or networks without the owner's explicit permission " +
                        "may violate computer misuse laws in many countries, and violate the terms of service of your " +
                        "ISP or hosting provider. Only use this app on:",
                    color = TextSecondary, style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                listOf(
                    "Your own devices and home network",
                    "Systems you have written permission to test (e.g. a CTF, lab, or authorized pentest)",
                    "Public test targets that explicitly allow scanning"
                ).forEach {
                    Text("•  $it", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
            }

            SectionCard {
                Text("Technical limitations", color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "• Service/version detection is based on banners the target voluntarily sends — it can be wrong " +
                        "or missing if a service is configured to hide its banner.\n\n" +
                        "• On the local network scanner, Android restricts access to the ARP table and randomizes MAC " +
                        "addresses on modern OS versions. MAC address, vendor, and \"device model\" fields are best-effort " +
                        "guesses derived from whatever hostname or MAC a device chooses to broadcast — there is no reliable " +
                        "way for an app to determine another device's exact model over WiFi.\n\n" +
                        "• Firewalls, VPNs, and carrier-grade NAT can cause open ports or live hosts to be missed entirely.",
                    color = TextSecondary, style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
