package com.eduscan.netscan.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eduscan.netscan.ui.components.GradientHeader
import com.eduscan.netscan.ui.theme.*

@Composable
fun HomeScreen(
    onOpenPortScanner: () -> Unit,
    onOpenLocalNetwork: () -> Unit,
    onOpenSubdomainFinder: () -> Unit,
    onOpenAbout: () -> Unit
) {
    Scaffold(containerColor = BgDeep) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            GradientHeader(
                title = "NetScan Edu",
                subtitle = "Educational port scanning & network discovery toolkit"
            )

            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

                ChannelCard(
                    channelLabel = "CH.01 · PORT SCAN",
                    accentColor = CyanAccent,
                    icon = Icons.Filled.Radar,
                    title = "Port & Service Scanner",
                    description = "Scan an IP address or domain to find open ports, identify services, and grab version banners.",
                    onClick = onOpenPortScanner
                )

                ChannelCard(
                    channelLabel = "CH.02 · LOCAL NETWORK",
                    accentColor = PurpleAccent,
                    icon = Icons.Filled.Devices,
                    title = "Local Network Scanner",
                    description = "Discover devices connected to your WiFi network — IP, hostname, and vendor guess.",
                    onClick = onOpenLocalNetwork
                )

                ChannelCard(
                    channelLabel = "CH.03 · SUBDOMAIN FINDER",
                    accentColor = MagentaAccent,
                    icon = Icons.Filled.Dns,
                    title = "Subdomain Finder",
                    description = "Enumerate a domain's subdomains by dictionary lookup and resolve each one to a live IP.",
                    onClick = onOpenSubdomainFinder
                )

                NoticeCard(onOpenAbout = onOpenAbout)
            }
        }
    }
}

/**
 * A "channel" readout row - a left accent bar plus a tracked micro-label
 * (CH.01 / CH.02), echoing how a dual-trace instrument labels its inputs.
 * The numbering is real here: there are exactly two distinct scan modes.
 */
@Composable
private fun ChannelCard(
    channelLabel: String,
    accentColor: Color,
    icon: ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BgCard),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(accentColor)
            )
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(channelLabel, color = accentColor, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(title, color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(description, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextMuted)
            }
        }
    }
}

/** Disclaimer styled like a caution placard - same left-bar language as the
 *  channel cards above, so the structure reads as "one more typed entry"
 *  rather than a bolted-on legal notice. */
@Composable
private fun NoticeCard(onOpenAbout: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = BgCard),
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(StatusWarning)
            )
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.School, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("FOR EDUCATIONAL USE", color = StatusWarning, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Only scan networks and devices you own or have explicit permission to test. " +
                        "Scanning systems without authorization may be illegal in your jurisdiction.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onOpenAbout, contentPadding = PaddingValues(0.dp)) {
                    Text("Read full disclaimer", color = CyanAccent)
                }
            }
        }
    }
}
