package com.eduscan.netscan.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Single fixed dark scheme by design: this is an instrument panel, not a
// content surface, so it doesn't follow the system light/dark toggle.
private val NetScanDarkColors = darkColorScheme(
    primary = CyanAccent,          // CH.1 amber
    onPrimary = BgDeep,
    secondary = PurpleAccent,      // CH.2 teal
    onSecondary = BgDeep,
    background = BgDeep,
    onBackground = TextPrimary,
    surface = BgSurface,
    onSurface = TextPrimary,
    surfaceVariant = BgSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    error = StatusError,
    onError = BgDeep,
    outline = BorderSubtle
)

@Composable
fun NetScanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = NetScanDarkColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NetScanTypography,
        content = content
    )
}
