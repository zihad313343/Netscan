# NetScan Edu

An educational Android app (Kotlin + Jetpack Compose) for learning basic network
reconnaissance: TCP port scanning, service/version identification via banner
grabbing, and local WiFi device discovery.

## ⚠️ Use responsibly

Only scan devices, servers, and networks you **own** or have **explicit written
permission** to test. Unauthorized scanning can violate computer misuse laws
(e.g. the U.S. Computer Fraud and Abuse Act, UK Computer Misuse Act, etc.) and
your ISP's terms of service. This app is intended for home labs, your own
devices, CTFs, and authorized security coursework.

## Features

- **Port & Service Scanner** — enter an IP or domain, choose a common port list,
  the full 1–1023 well-known range, or a custom range. Scans concurrently with
  coroutines and a TCP connect-scan (`Socket.connect` with a short timeout).
- **Banner grabbing** — for HTTP(S)-like ports, sends a `HEAD /` probe and reads
  the `Server:` header; for other ports (SSH, FTP, SMTP, etc.) it reads whatever
  banner the service sends on connect; a regex pulls out a rough version string.
- **Local Network Scanner** — reads your WiFi subnet from `WifiManager`, sweeps
  all 254 addresses (ICMP `isReachable` + a TCP-port fallback since ICMP is often
  blocked), reverse-DNS resolves hostnames, and best-effort reads `/proc/net/arp`
  for MAC addresses, then maps the OUI prefix to a vendor guess.
- Dark "network ops" Material 3 theme, single activity, Compose Navigation.

## Known limitations (read this before assuming a bug)

- **No API exists for reading another device's exact model** over WiFi. The app
  shows whatever a device chooses to broadcast (hostname, e.g. `Johns-iPhone`)
  and a vendor guess from its MAC — not a guaranteed model name.
- Android 10+ locks down ARP table access and randomizes MAC addresses by
  default, so MAC/vendor fields will often be empty — this is an OS-level
  privacy restriction, not something an app can bypass without root.
- Banner grabbing only works if the target service actually sends one; many
  hardened servers suppress version banners deliberately.

## Build instructions

1. Install **Android Studio** (Koala/2024.1 or newer recommended).
2. Open this project folder (`netscan-app/`) in Android Studio — it will
   auto-sync Gradle using the included `settings.gradle.kts` / `build.gradle.kts`.
3. Let Gradle sync finish (it will download the Compose BOM, Navigation, and
   Kotlin coroutines dependencies — first sync needs internet access).
4. Run on a device or emulator with **minSdk 26+** (Android 8.0+).
   - For the Local Network Scanner, run on a **real device connected to WiFi**
     (emulators don't have a real subnet to scan).

No API keys, backend, or special setup needed — everything runs on-device.

## Project structure

```
app/src/main/java/com/eduscan/netscan/
  MainActivity.kt
  model/Models.kt              - data classes for scan state/results
  network/
    ServiceDatabase.kt         - port -> service name table
    PortScanner.kt             - concurrent TCP connect scanner
    BannerGrabber.kt           - banner capture + version parsing
    LocalNetworkScanner.kt     - WiFi subnet sweep + ARP/hostname lookup
    OuiVendorDb.kt             - MAC prefix -> vendor sample table
  viewmodel/                   - PortScanViewModel, LocalNetworkViewModel
  ui/
    theme/                     - Color.kt, Theme.kt, Type.kt
    components/Common.kt       - shared Compose widgets
    screens/                   - Home, PortScan, LocalNetwork, About
    nav/NavGraph.kt
```

## Ideas for extending it (left as an exercise)

- Swap the tiny `OuiVendorDb` sample table for a full IEEE OUI CSV bundled as
  an asset, for much better vendor coverage.
- Add mDNS/Bonjour (`NsdManager`) discovery to pick up richer device names on
  networks where devices advertise via `_device-info._tcp` etc.
- Persist scan history locally with Room.
- Add a "scan my own public IP" mode that only checks ports open to the
  internet (useful for checking your own router's exposed services).
